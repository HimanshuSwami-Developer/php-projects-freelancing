<?php
include("include/header.php");
include("include/sidebar.php");
include("assets/config/db.php");

$msg = "";

// Check if we are editing a subscription plan
$edit_mode = false;
$edit_data = [];

if(isset($_GET['edit_id']) && is_numeric($_GET['edit_id'])){
    $edit_mode = true;
    $edit_id = intval($_GET['edit_id']);
    $res = mysqli_query($con, "SELECT * FROM subscription_plans WHERE id=$edit_id");
    if(mysqli_num_rows($res) > 0){
        $edit_data = mysqli_fetch_assoc($res);
        
        // Fetch features for this plan
        $features_res = mysqli_query($con, "SELECT feature_text, is_included FROM plan_features WHERE plan_id=$edit_id ORDER BY sort_order ASC");
        $edit_features = [];
        while($feature = mysqli_fetch_assoc($features_res)){
            $edit_features[$feature['feature_text']] = (bool)$feature['is_included'];
        }
        $edit_data['features'] = $edit_features;
    } else {
        $msg = "Subscription plan not found!";
        $edit_mode = false;
    }
}

// Handle Add/Edit submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $plan_key = mysqli_real_escape_string($con, $_POST['plan_key']);
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $subtitle = mysqli_real_escape_string($con, $_POST['subtitle']);
    $original_price = mysqli_real_escape_string($con, $_POST['original_price']);
    $sale_price = mysqli_real_escape_string($con, $_POST['sale_price']);
    $payment_note = mysqli_real_escape_string($con, $_POST['payment_note']);
    $status = isset($_POST['status']) ? 1 : 0;

    if(isset($_POST['edit_id']) && is_numeric($_POST['edit_id'])){
        // Update existing plan
        $edit_id = intval($_POST['edit_id']);
        
        // Check if plan key already exists (excluding current plan)
        $check_sql = "SELECT id FROM subscription_plans WHERE plan_key='$plan_key' AND id != $edit_id";
        $check_result = mysqli_query($con, $check_sql);
        if(mysqli_num_rows($check_result) > 0){
            $msg = "Error: Plan key already exists!";
        } else {
            $sql = "UPDATE subscription_plans SET 
                        plan_key='$plan_key', 
                        name='$name', 
                        subtitle='$subtitle', 
                        original_price='$original_price', 
                        sale_price='$sale_price', 
                        payment_note='$payment_note',
                        is_active='$status'
                    WHERE id=$edit_id";
            
            if(mysqli_query($con, $sql)){
                // Delete existing features
                mysqli_query($con, "DELETE FROM plan_features WHERE plan_id=$edit_id");
                
                // Insert new features
                if(isset($_POST['feature_text']) && is_array($_POST['feature_text'])){
                    $order = 0;
                    foreach($_POST['feature_text'] as $index => $feature_text){
                        $feature_text = mysqli_real_escape_string($con, $feature_text);
                        $is_included = isset($_POST['feature_included'][$index]) ? 1 : 0;
                        
                        if(!empty(trim($feature_text))){
                            $feature_sql = "INSERT INTO plan_features (plan_id, feature_text, is_included, sort_order) 
                                           VALUES ($edit_id, '$feature_text', '$is_included', '$order')";
                            mysqli_query($con, $feature_sql);
                            $order++;
                        }
                    }
                }
                
                $msg = "Subscription plan updated successfully!";
            } else {
                $msg = "Error: ".mysqli_error($con);
            }
        }
    } else {
        // Add new plan
        // Check if plan key already exists
        $check_sql = "SELECT id FROM subscription_plans WHERE plan_key='$plan_key'";
        $check_result = mysqli_query($con, $check_sql);
        if(mysqli_num_rows($check_result) > 0){
            $msg = "Error: Plan key already exists!";
        } else {
            $sql = "INSERT INTO subscription_plans (plan_key, name, subtitle, original_price, sale_price, payment_note, is_active) 
                    VALUES ('$plan_key','$name','$subtitle','$original_price','$sale_price','$payment_note','$status')";
            
            if(mysqli_query($con, $sql)){
                $plan_id = mysqli_insert_id($con);
                
                // Insert features
                if(isset($_POST['feature_text']) && is_array($_POST['feature_text'])){
                    $order = 0;
                    foreach($_POST['feature_text'] as $index => $feature_text){
                        $feature_text = mysqli_real_escape_string($con, $feature_text);
                        $is_included = isset($_POST['feature_included'][$index]) ? 1 : 0;
                        
                        if(!empty(trim($feature_text))){
                            $feature_sql = "INSERT INTO plan_features (plan_id, feature_text, is_included, sort_order) 
                                           VALUES ($plan_id, '$feature_text', '$is_included', '$order')";
                            mysqli_query($con, $feature_sql);
                            $order++;
                        }
                    }
                }
                
                $msg = "Subscription plan added successfully!";
            } else {
                $msg = "Error: ".mysqli_error($con);
            }
        }
    }
}

// Handle delete
if(isset($_GET['delete_id']) && is_numeric($_GET['delete_id'])){
    $delete_id = intval($_GET['delete_id']);
    mysqli_query($con, "DELETE FROM plan_features WHERE plan_id=$delete_id");
    mysqli_query($con, "DELETE FROM subscription_plans WHERE id=$delete_id");
    $msg = "Subscription plan deleted successfully!";
}

// Handle status toggle
if(isset($_GET['toggle_status']) && is_numeric($_GET['toggle_status'])){
    $toggle_id = intval($_GET['toggle_id']);
    $current_status = mysqli_fetch_assoc(mysqli_query($con, "SELECT is_active FROM subscription_plans WHERE id=$toggle_id"));
    $new_status = $current_status['is_active'] ? 0 : 1;
    mysqli_query($con, "UPDATE subscription_plans SET is_active=$new_status WHERE id=$toggle_id");
    $msg = "Plan status updated successfully!";
}

// Fetch all subscription plans with feature count
$plans = mysqli_query($con, "SELECT sp.*, 
                            (SELECT COUNT(*) FROM plan_features WHERE plan_id = sp.id) as feature_count
                            FROM subscription_plans sp 
                            ORDER BY sp.id DESC");
?>

<main class="dashboard-gssecurity-main" style="padding:20px;">
    <div class="dashboard-gssecurity-title" style="font-size:28px; margin-bottom:20px;">
        <?php echo $edit_mode ? "Edit Subscription Plan" : "Add Subscription Plan"; ?>
    </div>

    <?php if($msg){ echo "<p style='color:green;font-weight:bold; margin-bottom:15px;'>$msg</p>"; } ?>

    <!-- Add/Edit Form -->
    <div style="background:#fff; padding:25px; border-radius:10px; box-shadow:0 5px 15px rgba(0,0,0,0.1); max-width:800px; margin-bottom:40px;">
        <form action="" method="POST" style="display:grid; grid-gap:15px;">
            <div style="display:grid; grid-template-columns:1fr 1fr; grid-gap:15px;">
                <div>
                    <label style="font-weight:bold;">Plan Key *</label>
                    <input type="text" name="plan_key" value="<?php echo $edit_mode ? htmlspecialchars($edit_data['plan_key']) : ''; ?>" required style="padding:8px; border-radius:5px; border:1px solid #ccc; width:100%;">
                    <small style="color:#666;">Unique identifier (e.g., gold, silver, bronze)</small>
                </div>
                
                <div>
                    <label style="font-weight:bold;">Plan Name *</label>
                    <input type="text" name="name" value="<?php echo $edit_mode ? htmlspecialchars($edit_data['name']) : ''; ?>" required style="padding:8px; border-radius:5px; border:1px solid #ccc; width:100%;">
                </div>
            </div>

            <label style="font-weight:bold;">Subtitle</label>
            <input type="text" name="subtitle" value="<?php echo $edit_mode ? htmlspecialchars($edit_data['subtitle']) : ''; ?>" style="padding:8px; border-radius:5px; border:1px solid #ccc;">

            <div style="display:grid; grid-template-columns:1fr 1fr; grid-gap:15px;">
                <div>
                    <label style="font-weight:bold;">Original Price (£) *</label>
                    <input type="number" step="0.01" name="original_price" value="<?php echo $edit_mode ? $edit_data['original_price'] : ''; ?>" required style="padding:8px; border-radius:5px; border:1px solid #ccc; width:100%;">
                </div>
                
                <div>
                    <label style="font-weight:bold;">Sale Price (£) *</label>
                    <input type="number" step="0.01" name="sale_price" value="<?php echo $edit_mode ? $edit_data['sale_price'] : ''; ?>" required style="padding:8px; border-radius:5px; border:1px solid #ccc; width:100%;">
                </div>
            </div>

            <label style="font-weight:bold;">Payment Note</label>
            <input type="text" name="payment_note" value="<?php echo $edit_mode ? htmlspecialchars($edit_data['payment_note']) : ''; ?>" style="padding:8px; border-radius:5px; border:1px solid #ccc;">

            <div style="display:flex; align-items:center; gap:10px;">
                <input type="checkbox" name="status" value="1" id="status" <?php echo $edit_mode && $edit_data['is_active'] ? 'checked' : 'checked'; ?> style="transform:scale(1.2);">
                <label style="font-weight:bold;" for="status">Active Plan</label>
            </div>

            <!-- Features Section -->
            <div style="border:1px solid #ddd; padding:15px; border-radius:5px;">
                <label style="font-weight:bold; display:block; margin-bottom:10px;">Plan Features</label>
                <div id="features-container">
                    <?php if($edit_mode && !empty($edit_data['features'])): ?>
                        <?php $feature_index = 0; ?>
                        <?php foreach($edit_data['features'] as $feature_text => $is_included): ?>
                            <div class="feature-item" style="display:flex; gap:10px; align-items:center; margin-bottom:10px;">
                                <input type="text" name="feature_text[]" value="<?php echo htmlspecialchars($feature_text); ?>" placeholder="Feature description" style="flex:1; padding:8px; border-radius:5px; border:1px solid #ccc;">
                                <div style="display:flex; align-items:center; gap:5px;">
                                    <input type="checkbox" name="feature_included[]" value="1" <?php echo $is_included ? 'checked' : ''; ?> style="transform:scale(1.2);">
                                    <span style="font-size:14px;">Included</span>
                                </div>
                                <button type="button" class="remove-feature" style="background:red; color:white; border:none; padding:5px 10px; border-radius:3px; cursor:pointer;">Remove</button>
                            </div>
                            <?php $feature_index++; ?>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="feature-item" style="display:flex; gap:10px; align-items:center; margin-bottom:10px;">
                            <input type="text" name="feature_text[]" placeholder="Feature description" style="flex:1; padding:8px; border-radius:5px; border:1px solid #ccc;">
                            <div style="display:flex; align-items:center; gap:5px;">
                                <input type="checkbox" name="feature_included[]" value="1" checked style="transform:scale(1.2);">
                                <span style="font-size:14px;">Included</span>
                            </div>
                            <button type="button" class="remove-feature" style="background:red; color:white; border:none; padding:5px 10px; border-radius:3px; cursor:pointer;">Remove</button>
                        </div>
                    <?php endif; ?>
                </div>
                <button type="button" id="add-feature" style="background:#28a745; color:white; border:none; padding:8px 15px; border-radius:5px; cursor:pointer; margin-top:10px;">Add Feature</button>
            </div>

            <?php if($edit_mode){ ?>
                <input type="hidden" name="edit_id" value="<?php echo $edit_data['id']; ?>">
            <?php } ?>

            <button type="submit" style="background:#007BFF; color:#fff; padding:12px 25px; border:none; border-radius:5px; cursor:pointer; font-size:16px; font-weight:bold;">
                <?php echo $edit_mode ? "Update Plan" : "Add Plan"; ?>
            </button>
        </form>
    </div>

    <!-- Subscription Plans Table -->
    <div class="dashboard-gssecurity-title" style="font-size:28px; margin-bottom:15px;">All Subscription Plans</div>
    <table style="width:100%; border-collapse:collapse; box-shadow:0 3px 10px rgba(0,0,0,0.1);">
        <thead>
            <tr style="background:#007BFF; color:#fff; text-align:left;">
                <th style="padding:12px;">ID</th>
                <th style="padding:12px;">Plan Key</th>
                <th style="padding:12px;">Name</th>
                <th style="padding:12px;">Subtitle</th>
                <th style="padding:12px;">Prices</th>
                <th style="padding:12px;">Features</th>
                <th style="padding:12px;">Status</th>
                <th style="padding:12px;">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if(mysqli_num_rows($plans) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($plans)){ ?>
                <tr style="border-bottom:1px solid #ccc; transition:background 0.3s;" onmouseover="this.style.background='#f1f1f1'" onmouseout="this.style.background='transparent'">
                    <td style="padding:10px;"><?php echo $row['id']; ?></td>
                    <td style="padding:10px;"><code><?php echo htmlspecialchars($row['plan_key']); ?></code></td>
                    <td style="padding:10px; font-weight:bold;"><?php echo htmlspecialchars($row['name']); ?></td>
                    <td style="padding:10px;"><?php echo htmlspecialchars($row['subtitle']); ?></td>
                    <td style="padding:10px;">
                        <del>£<?php echo $row['original_price']; ?></del><br>
                        <strong style="color:#007BFF;">£<?php echo $row['sale_price']; ?></strong>
                    </td>
                    <td style="padding:10px;"><?php echo $row['feature_count']; ?> features</td>
                    <td style="padding:10px;">
                        <span style="padding:4px 8px; border-radius:3px; font-size:12px; font-weight:bold; background:<?php echo $row['is_active'] ? '#28a745' : '#6c757d'; ?>; color:white;">
                            <?php echo $row['is_active'] ? 'Active' : 'Inactive'; ?>
                        </span>
                    </td>
                    <td style="padding:10px;">
                        <a href="?edit_id=<?php echo $row['id']; ?>" style="padding:5px 10px; background:orange;color:#fff;border-radius:5px;text-decoration:none; margin-right:5px;">Edit</a>
                        <a href="?toggle_status=1&toggle_id=<?php echo $row['id']; ?>" style="padding:5px 10px; background:<?php echo $row['is_active'] ? '#6c757d' : '#28a745'; ?>;color:#fff;border-radius:5px;text-decoration:none; margin-right:5px;">
                            <?php echo $row['is_active'] ? 'Disable' : 'Enable'; ?>
                        </a>
                        <a href="?delete_id=<?php echo $row['id']; ?>" style="padding:5px 10px; background:red;color:#fff;border-radius:5px;text-decoration:none;" onclick="return confirm('Are you sure you want to delete this plan?')">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        <?php else: ?>
            <tr>
                <td colspan="8" style="text-align:center; padding:20px; color:#666;">
                    No subscription plans found. Add your first plan above.
                </td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</main>

<script>
// Feature management
document.addEventListener('DOMContentLoaded', function() {
    const addFeatureBtn = document.getElementById('add-feature');
    const featuresContainer = document.getElementById('features-container');
    
    addFeatureBtn.addEventListener('click', function() {
        const newFeature = document.createElement('div');
        newFeature.className = 'feature-item';
        newFeature.style.cssText = 'display:flex; gap:10px; align-items:center; margin-bottom:10px;';
        newFeature.innerHTML = `
            <input type="text" name="feature_text[]" placeholder="Feature description" style="flex:1; padding:8px; border-radius:5px; border:1px solid #ccc;">
            <div style="display:flex; align-items:center; gap:5px;">
                <input type="checkbox" name="feature_included[]" value="1" checked style="transform:scale(1.2);">
                <span style="font-size:14px;">Included</span>
            </div>
            <button type="button" class="remove-feature" style="background:red; color:white; border:none; padding:5px 10px; border-radius:3px; cursor:pointer;">Remove</button>
        `;
        featuresContainer.appendChild(newFeature);
    });
    
    featuresContainer.addEventListener('click', function(e) {
        if(e.target.classList.contains('remove-feature')) {
            e.target.closest('.feature-item').remove();
        }
    });
});
</script>