<?php
session_start();

// --- Mock Team Data (Replace with your actual team members) ---
$team_members = [
    [
        'name' => 'John R. Sterling',
        'title' => 'Founder & CEO',
        'bio' => 'A security veteran with 30+ years of experience, John leads our mission to provide industry-leading training and services.',
        'image_url' => 'https://placehold.co/400x400/00C1EC/FFFFFF?text=J.S.',
    ],
    [
        'name' => 'Sarah L. Adams',
        'title' => 'Lead Trainer & Compliance Officer',
        'bio' => 'Sarah is responsible for ensuring all our courses meet strict SIA and industry compliance standards. She holds several advanced security certifications.',
        'image_url' => 'https://placehold.co/400x400/1a1a1a/FFFFFF?text=S.A.',
    ],
    [
        'name' => 'Michael B. Carter',
        'title' => 'Operations Manager',
        'bio' => 'Michael manages the deployment of our security services division, specializing in large event management and corporate site protection.',
        'image_url' => 'https://placehold.co/400x400/00C1EC/FFFFFF?text=M.C.',
    ],
    [
        'name' => 'Emily P. Davis',
        'title' => 'Customer Success Director',
        'bio' => 'Emily heads the student support team, ensuring every learner receives personalized guidance from enrollment through certification and job placement assistance.',
        'image_url' => 'https://placehold.co/400x400/1a1a1a/FFFFFF?text=E.D.',
    ],
];
// --- End Mock Team Data ---

// NOTE: No form submission logic is needed for this static content page.
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Meet Our Team | G Security and Training</title>
    <meta name="description" content="Meet the experienced and dedicated team behind G Security and Training, committed to delivering professional security services and top-tier SIA training.">
    
    <!-- Load required scripts and styles -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    
    <!-- Custom Tailwind Configuration -->
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'accent-blue': '#00C1EC',
                        'charcoal': '#181818',
                        'light-gray-bg': '#f8f8f8',
                    }
                }
            }
        }
    </script>
    
    <?php include "includes/head.php" ?>
</head>

<body class="bg-light-gray-bg">
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PCQD3VJQ"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    
    <div>
        <?php include "includes/header.php" ?>

        <!-- Body -->
        <div class="bg-light-gray-bg py-12 md:py-20 min-h-screen">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

                <!-- Page Header -->
                <div class="text-center mb-16">
                    <h1 class="text-4xl md:text-6xl font-black text-gray-900 mb-4">
                        Meet Our <span class="text-accent-blue">Expert Team</span>
                    </h1>
                    <p class="text-xl text-gray-600 max-w-3xl mx-auto">
                        Committed to your safety and career success, our team of seasoned professionals brings decades of experience from every corner of the security industry.
                    </p>
                </div>

                <!-- Team Grid -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                    
                    <?php foreach ($team_members as $member) { ?>
                        
                        <!-- Team Member Card -->
                        <div class="bg-white rounded-xl shadow-xl overflow-hidden transform transition duration-300 hover:scale-[1.02] hover:shadow-2xl h-full flex flex-col">
                            
                            <!-- Image Section -->
                            <div class="relative overflow-hidden flex-shrink-0">
                                <img src="<?= $member['image_url'] ?>" alt="<?= $member['name'] ?> - <?= $member['title'] ?>" class="w-full h-64 object-cover object-top transition-transform duration-500 hover:scale-105">
                                <div class="absolute inset-0 bg-black opacity-10"></div> 
                            </div>
                            
                            <!-- Content Section -->
                            <div class="p-6 flex-grow flex flex-col justify-between">
                                <div>
                                    <h3 class="text-2xl font-bold text-gray-900 mb-1"><?= $member['name'] ?></h3>
                                    <p class="text-lg font-semibold text-accent-blue mb-4"><?= $member['title'] ?></p>
                                    
                                    <blockquote class="text-gray-700 italic border-l-4 border-gray-200 pl-4">
                                        "<?= $member['bio'] ?>"
                                    </blockquote>
                                </div>
                                
                                <!-- Social Links (Optional - adjust links as needed) -->
                                <div class="flex space-x-3 mt-6">
                                    <a href="#" class="text-gray-500 hover:text-accent-blue transition duration-200">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M22 6c-2.4 1.3-4.9 2.2-7.5 2.5c-2.5-1.5-5.5-1.6-8.2-.3c-.6.3-1.1.7-1.6 1.1c-.6.5-1.1 1.1-1.5 1.7c-.5.6-.9 1.3-1.2 2c-.3.7-.5 1.4-.6 2.2c-.1.8 0 1.6.2 2.4c.2.8.5 1.5.8 2.2c.4.7.7 1.4 1.2 2c.5.6 1.1 1.1 1.7 1.5c.6.4 1.3.7 2 1c.7.2 1.4.4 2.1.4c1.6 0 3.2-.4 4.7-1.2c1.5-.8 2.8-1.9 3.8-3.3c1-1.4 1.7-3 2.1-4.7c.4-1.7.4-3.5 0-5.2c.2-.2.3-.5.5-.7c.6-.6 1.3-1.1 2-1.5c-.5.5-1.1.9-1.7 1.2c-.4.2-.7.4-1.1.5c.5-.3 1-.7 1.4-1.2"/></svg>
                                    </a>
                                    <a href="#" class="text-gray-500 hover:text-accent-blue transition duration-200">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.75s.784-1.75 1.75-1.75 1.75.79 1.75 1.75-.783 1.75-1.75 1.75zm13.5 12.268h-3v-5.602c0-3.376-4-3.593-4 0v5.602h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                                    </a>
                                </div>
                            </div>
                        </div>

                    <?php } ?>
                </div>

                <!-- Call to Action Banner -->
                <div class="mt-20 p-10 bg-white rounded-xl shadow-2xl border-t-8 border-gray-400 text-center">
                    <h2 class="text-3xl font-extrabold text-gray-900 mb-3">Ready to Join the Security Industry?</h2>
                    <p class="text-lg text-gray-700 mb-6">Start your journey with the team that supports your success from day one.</p>
                    <a href="courses" class="inline-block bg-accent-blue text-white px-8 py-3 rounded-lg font-bold hover:bg-blue-700 transition duration-200 shadow-lg text-lg">
                        View Training Courses
                    </a>
                </div>

            </div>
        </div>

        <!-- Footer -->
        <?php include "includes/footer.php" ?>
    </div>
    
    <!-- Toggle Script -->
    <?php include "includes/foot.php" ?>
</body>
</html>
